
# Online Python - IDE, Editor, Compiler, Interpreter
#2 integer addition Assignment
num1 = 15
num2=17
total=num1 + num2
print( total)
